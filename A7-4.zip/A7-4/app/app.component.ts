import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent 
{
  title = 'Q4';
  public str="";
  public ptr="";
  public Upper()
  {
    this.str="MARVELLOUS INFOSYSTEM";
  }
  public lower()
  {
    this.ptr="marvellous infosystem"
  }
}
