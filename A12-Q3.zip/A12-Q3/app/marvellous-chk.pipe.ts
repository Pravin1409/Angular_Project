import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
  name: 'marvellousChk'
})
export class MarvellousChkPipe implements PipeTransform {

  transform(value:number,Para:string):any
  {

    let str="";
    if(Para=="Prime")
    {
      if(value%2!=0)
      {
        return str=value+":is prime number"
      }
      else
      {
        return str=value+"is not prime number"
      }
    }
    if(Para=="Even")
    {
      if(value%2==0)
      {
        return str=value+":is Even Number";
      }
      else
      {
        return str=value+":is not Event number"
      }
    }
    if(Para=="Perfect")
    {
      let sum:number=0;
      for(let i=1;i<=(value/2);i++)
      {
        if(value%i==0)
        {
          sum=sum+i;
        }
      }
      if(value==sum)
      {
        return str=value+":is a perfect number";
      }
      else
      {
        return str=value+":is not perfect number";
      }
    }
  }

}
