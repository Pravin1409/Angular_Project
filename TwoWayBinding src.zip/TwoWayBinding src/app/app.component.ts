import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent 
{
  title = 'TwoWayBinding';
  public Data="Hello html";
  public ptr="";
  public fun(Data:any)
  {
    this.ptr=Data;
  }
  public Name:any;
}
