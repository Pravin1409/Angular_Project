import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'EventBinding';
  public str="";
  public Input()
  {
    this.str="Hellooo...";
  }
  public gun(Data:any)
  {
    console.log(Data);
  }
}
