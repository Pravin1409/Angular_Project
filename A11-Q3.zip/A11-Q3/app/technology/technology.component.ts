import { Component, OnInit } from '@angular/core';
import { DetailService } from '../detail.service';

@Component({
  selector: 'app-technology',
  templateUrl: './technology.component.html',
  styleUrls: ['./technology.component.css']
})
export class TechnologyComponent implements OnInit 
{

  constructor(private _obj:DetailService) { }
  public Books:any=[];

  ngOnInit(): void 
  {
    this.Books=this._obj.GetData().subscribe(data=>this.Books=data);
  }

}
