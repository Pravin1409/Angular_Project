import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { BooksComponent } from './books/books.component';
import { TechnologyComponent } from './technology/technology.component';
import { WrongComponent } from './wrong/wrong.component';

const routes: Routes = [
{path:'Books',component:BooksComponent},
{path:'technology',component:TechnologyComponent},
{path:'',component:TechnologyComponent},
{path:'**',component:WrongComponent}



];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
