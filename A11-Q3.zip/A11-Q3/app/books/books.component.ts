import { Component, OnInit } from '@angular/core';
import { DetailService } from '../detail.service';

@Component({
  selector: 'app-books',
  templateUrl: './books.component.html',
  styleUrls: ['./books.component.css']
})
export class BooksComponent implements OnInit 
{

  constructor(private _obj:DetailService) { }
  public Books:any=[];

  ngOnInit(): void 
  {
    this.Books=this._obj.GetData().subscribe(data=>this.Books=data);
  }

}
