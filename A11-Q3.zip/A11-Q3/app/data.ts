export interface IData
{
    Name:string,
    Books:string
}