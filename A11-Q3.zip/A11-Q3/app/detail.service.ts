import { Injectable } from '@angular/core';
import { IData } from './data';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class DetailService 
{

  constructor(private _obj:HttpClient) { }
  public URL='/assets/Data/detail.json';

  public GetData():Observable<IData[]>
  {
    return this._obj.get<IData[]>(this.URL);
  }
}
