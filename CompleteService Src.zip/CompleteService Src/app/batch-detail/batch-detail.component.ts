import { Component, OnInit } from '@angular/core';
import { BatchService } from '../batch.service';

@Component({
  selector: 'app-batch-detail',
  template: `
  <h1>Inside Batches Detail</h1>

  <ul *ngFor="let value of Batches">
    <li>Name of Batch {{value.Name}} with Duration {{value.Duration}} having Fees {{value.Fees}} thousand rupees</li>
    </ul>
  
  `
})
export class BatchDetailComponent implements OnInit 
{

  constructor(private _obj:BatchService) { }
  public Batches:any=[];

  ngOnInit(): void 
  {
    this.Batches=this._obj.GetBatches().subscribe(data=>this.Batches=data)
  }

}
