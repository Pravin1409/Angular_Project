import { Component, OnInit } from '@angular/core';
import { BatchService } from '../batch.service';

@Component({
  selector: 'app-batches',
  template:`
  <h1>Inside Batches</h1>
  <ul *ngFor=" let value of Batches"> 
    <li>Name of Batches: {{value.Name}}</li>
  </ul>

  
  `
})
export class BatchesComponent implements OnInit 
{

  public Batches:any=[];
  constructor(private _obj:BatchService) { }

  ngOnInit(): void 
  {
    this.Batches=this._obj.GetBatches().subscribe(data=>this.Batches=data)
  }

}
