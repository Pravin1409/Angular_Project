export interface IBatches
{
    Name:string,
    Duration:number,
    Fees:number
}