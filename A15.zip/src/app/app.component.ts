import { ValueConverter } from '@angular/compiler/src/render3/view/template';
import { Component } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent
{
  title = 'reactive';
 constructor (public obj:FormBuilder)
 {

 }
 
 form=this.obj.group({
  name:['',[Validators.required,Validators.pattern("[a-z A-Z]*")]],
  last:['',[Validators.required,Validators.pattern("[a-z A-Z]*")]],
  mail:['',[Validators.required,Validators.pattern("[a-z0-9]\.+@[a-z]+\.[a-z]{2,3}")]],
  phone:['',[Validators.required, Validators.pattern("^[0-9]*$"),Validators.maxLength(10)]],
  city:['',[Validators.required,Validators.pattern("[a-z A-z]{4,}")]],
  zip:['',[Validators.required,Validators.pattern("[0-9]{5}")]],
  comment:['',[Validators.required,Validators.pattern("[a-z A-z]{30,}")]]

 })

}
