import { ComponentFixture, TestBed } from '@angular/core/testing';

import { CdemoComponent } from './cdemo.component';

describe('CdemoComponent', () => {
  let component: CdemoComponent;
  let fixture: ComponentFixture<CdemoComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ CdemoComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(CdemoComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
