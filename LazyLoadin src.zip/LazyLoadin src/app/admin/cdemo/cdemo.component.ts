import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-cdemo',
  templateUrl: './cdemo.component.html',
  styleUrls: ['./cdemo.component.css']
})
export class CdemoComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
