import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-bdemo',
  templateUrl: './bdemo.component.html',
  styleUrls: ['./bdemo.component.css']
})
export class BdemoComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
