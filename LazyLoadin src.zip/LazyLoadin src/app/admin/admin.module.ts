import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { AdminRoutingModule } from './admin-routing.module';
import { AdemoComponent } from './ademo/ademo.component';
import { BdemoComponent } from './bdemo/bdemo.component';
import { CdemoComponent } from './cdemo/cdemo.component';


@NgModule({
  declarations: [
    AdemoComponent,
    BdemoComponent,
    CdemoComponent
  ],
  imports: [
    CommonModule,
    AdminRoutingModule
  ],
  exports:[
    AdemoComponent
  ]
})
export class AdminModule { }
