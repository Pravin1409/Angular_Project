import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { AdemoComponent } from './ademo/ademo.component';
import { BdemoComponent } from './bdemo/bdemo.component';
import { CdemoComponent } from './cdemo/cdemo.component';

const routes: Routes = [
  {path:'',component:AdemoComponent},
  {path:'bdemo',component:BdemoComponent},
  {path:'cdemo',component:CdemoComponent}
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class AdminRoutingModule { }
