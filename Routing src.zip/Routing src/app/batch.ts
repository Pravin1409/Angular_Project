export interface IBatch
{
    Name:string,
    Duration:number,
    Fees:number
}