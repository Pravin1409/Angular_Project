import { Component, OnInit } from '@angular/core';
import { BatchService } from '../batch.service';

@Component({
  selector: 'app-batches',
  template:`
  <h2>Inside Batch Comp</h2>
  <ul *ngFor="let value of Batch">
    <li>Name of Batches: {{value.Name}}</li>
  </ul>
  `
  
  
  
})
export class BatchesComponent implements OnInit 
{
  public Batch:any=[]
  constructor(private _obj:BatchService) { }
 

  ngOnInit(): void 
  {
    this.Batch=this._obj.GetData().subscribe(data=>this.Batch=data);
  }

}
