import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { AboutComponent } from './about/about.component';
import { HomeComponent } from './home/home.component';
import { BatchDetailComponent } from './batch-detail/batch-detail.component';
import { BatchesComponent } from './batches/batches.component';


const routes: Routes = [

  {path:'about',component: AboutComponent},
  {path:'Home',component:HomeComponent},
  {path:'batch',component: BatchDetailComponent},
  {path:'bat',component: BatchesComponent}
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
