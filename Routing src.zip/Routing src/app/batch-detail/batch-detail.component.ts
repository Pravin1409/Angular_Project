import { Component, OnInit } from '@angular/core';
import { BatchService } from '../batch.service';

@Component({
  selector: 'app-batch-detail',
  template:`
  <h1>HAPPY</h1>
  <ul *ngFor="let value of Batches">
    <li>Name of Batch {{value.Name}} with Duration {{value.Duration}} having Fees {{value.Fees}}</li>
  
  </ul>

  `
})
export class BatchDetailComponent implements OnInit 
{
  public Batches:any=[];
  constructor(private _obj:BatchService) { }

  ngOnInit(): void 
  {
    this.Batches=this._obj.GetData().subscribe(data=>this.Batches=data);
  }

}
