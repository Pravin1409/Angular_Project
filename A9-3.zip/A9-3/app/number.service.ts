import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class NumberService 
{
  public ChkPrime(value:number)
  {
    if(value%2!=0)
    {
      return "Number is Prime";
    }
    else
    {
      return "Number is not Prime";
    }
  }
  constructor() { }
}
