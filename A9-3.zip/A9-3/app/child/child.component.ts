import { Component, OnInit } from '@angular/core';
import { NumberService } from '../number.service';
import { StringService } from '../string.service';

@Component({
  selector: 'app-child',
  template:`

<h1>{{str}}</h1>
<h2>Count of Number is:{{Num}}</h2>

  ` 
  
})
export class ChildComponent implements OnInit {

  constructor(private _obj:NumberService, private _sobj:StringService) { }
  public str:any
  public Num:number=0;
  public name:string="HelLo"
  ngOnInit(): void 
  {
    this.str=this._obj.ChkPrime(40);
    this.Num=this._sobj.CountCap(this.name)
  }

}
