import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class StringService 
{
  public CountCap(value:string)
  {
    var icnt:number=0;
    for(var i=0;i<value.length;i++)
    {
      var ch=value.charAt(i);
      if(ch>='A' && ch<='Z')
      {
        icnt++;
      }
    }
    return icnt;
  }
  constructor() { }
}
