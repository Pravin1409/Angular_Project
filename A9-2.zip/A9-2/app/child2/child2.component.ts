import { Component, OnInit } from '@angular/core';
import { StringService } from '../string.service';

@Component({
  selector: 'app-child2',
  template: `
  <h1>Count Are:{{count}}</h1>
  
  `
 
})
export class Child2Component implements OnInit {

  constructor(private _obj:StringService) { }
public count:number=0;
public str:string="PraviN Dongare";
  ngOnInit(): void 
  {
    this.count=this._obj.CountCapital(this.str);
  }

}
