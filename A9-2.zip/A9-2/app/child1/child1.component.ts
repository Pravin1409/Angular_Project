import { Component, OnInit } from '@angular/core';
import { NumberService } from '../number.service';

@Component({
  selector: 'app-child1',
  template: `
  <h1>{{str}}</h1>
  
  
  `
  
})
export class Child1Component implements OnInit {

  constructor(private _obj:NumberService) { }
  public str:any="";
  ngOnInit(): void 
  {
   
    this.str=this._obj.ChkPrime(22);
    
  }

}
