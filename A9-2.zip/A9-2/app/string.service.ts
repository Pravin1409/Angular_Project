import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class StringService 
{
  public CountCapital(value:String)
  {
    var icnt:number=0;
    for(var i=0;i<=value.length;i++)
    {
      var ch=value.charAt(i);
      
      if(ch>='A'&& ch<='Z')
      {
        icnt++;
      }  
    }
    return icnt;
   
  }
  constructor() { }
}
