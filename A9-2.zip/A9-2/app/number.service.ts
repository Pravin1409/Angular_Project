import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class NumberService 
{
  public No:number=0;

  public ChkPrime(value:number)
  {
    this.No=value;
    if(this.No%2!=0)
    {
      return "Number is Prime";
    }
    else
    {
      return "Number is not prime";
    }
  }
  constructor() { }
}
