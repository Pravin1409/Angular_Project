import { Component, OnInit, Output,EventEmitter } from '@angular/core';




@Component({
  selector: 'app-personal-info',
  templateUrl: './personal-info.component.html',
  styleUrls: ['./personal-info.component.css']
})
export class PersonalInfoComponent implements OnInit {
  
  constructor() { } 
  public Name:any;
  public Last:any;
  public mail:any;

  
  ngOnInit():void
  {
  }

}
