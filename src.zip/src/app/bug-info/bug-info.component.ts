import { Component, OnInit } from '@angular/core';
import {NgbTimeStruct} from '@ng-bootstrap/ng-bootstrap';
@Component({
  selector: 'app-bug-info',
  templateUrl: './bug-info.component.html',
  styleUrls: ['./bug-info.component.css']
})
export class BugInfoComponent implements OnInit {

 public detail:any;
 public bug:any;
  time: NgbTimeStruct = {hour:0, minute: 0, second:0};

  seconds = true;

  toggleSeconds() 
  {
    this.seconds = !this.seconds
    
    
  }








  
  constructor() { }

  ngOnInit(): void
  {

  } 
}
