import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent 
{
  title = 'StyleBinding';
  public Mycolor="orange";
  public ptr="";
  public Veg=true;
  public gun()
  {
    if(this.Veg==true)
    {
      this.ptr="You select veg";
    }
    else
    {
      this.ptr="You select non veg";
    }

  }
}
