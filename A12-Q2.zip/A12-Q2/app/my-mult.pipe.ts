import { Pipe, PipeTransform } from '@angular/core';
import { multicast } from 'rxjs';

@Pipe({
  name: 'myMult'
})
export class MyMultPipe implements PipeTransform {

  transform(value:number,Para:number):number 
  {
    let Multi:number=0;
    Multi=value*Para;
    return Multi;
  }

}
