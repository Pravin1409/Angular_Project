import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
  name: 'myAdd'
})
export class MyAddPipe implements PipeTransform {

  transform(value:number,Para:number):number
  {
    let Add:number=0;
    Add=value+Para;
    return Add;
  }
  

  
}
