import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-batches',
  template:` 
  
  <h1>Inside Batches</h1>
  <ul *ngFor="let value of Batches">
    <li>{{value.Name}}</li>
  </ul>


  
  `
  
})
export class BatchesComponent implements OnInit 
{

  public Batches=[

    {"Name":"PPA","Duration":4,"Fees":15000},
    {"Name":"LB","Duration":3,"Fees":14000},
    {"Name":"LSP","Duration":4.5,"Fees":15500},
    {"Name":"Angular","Duration":3.5,"Fees":15400}

  ]

  constructor() { }

  ngOnInit(): void {
  }

}
