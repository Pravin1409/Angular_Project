import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-batch-detail',
  template: `
  <h2>Inside Batch detail</h2>
  <ul *ngFor="let value of Batches"> 
    <li>{{value.Name}}with Duration {{value.Duration}} month  having {{value.Fees}} thoudand rupee</li>
  </ul>
  `
  
})
export class BatchDetailComponent implements OnInit {

  public Batches=[

    {"Name":"PPA","Duration":4,"Fees":15000},
    {"Name":"LB","Duration":3,"Fees":14000},
    {"Name":"LSP","Duration":4.5,"Fees":15500},
    {"Name":"Angular","Duration":3.5,"Fees":15400}
  ]
  constructor() { }

  ngOnInit(): void {
  }

}
