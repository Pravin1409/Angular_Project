import { ComponentFixture, TestBed } from '@angular/core/testing';

import { BigbroComponent } from './bigbro.component';

describe('BigbroComponent', () => {
  let component: BigbroComponent;
  let fixture: ComponentFixture<BigbroComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ BigbroComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(BigbroComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
