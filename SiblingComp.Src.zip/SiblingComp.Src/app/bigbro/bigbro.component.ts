import { Component, Input, OnInit } from '@angular/core';

@Component({
  selector: 'app-bigbro',
  templateUrl: './bigbro.component.html',
  styleUrls: ['./bigbro.component.css']
})
export class BigbroComponent 
{

  @Input() public Mess:any;
  

}
