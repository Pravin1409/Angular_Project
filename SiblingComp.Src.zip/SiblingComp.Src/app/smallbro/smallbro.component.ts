import { Component, OnInit, Output, EventEmitter} from '@angular/core';


@Component({
  selector: 'app-smallbro',
  templateUrl: './smallbro.component.html',
  styleUrls: ['./smallbro.component.css']
})
export class SmallbroComponent  
{
  @Output() public Myevent=new EventEmitter();

  public str="";
  
  public fun(Data:any)
  {
    this.str=Data;
    this.Myevent.emit(this.str);
  }
 
}
