import { ComponentFixture, TestBed } from '@angular/core/testing';

import { SmallbroComponent } from './smallbro.component';

describe('SmallbroComponent', () => {
  let component: SmallbroComponent;
  let fixture: ComponentFixture<SmallbroComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ SmallbroComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(SmallbroComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
