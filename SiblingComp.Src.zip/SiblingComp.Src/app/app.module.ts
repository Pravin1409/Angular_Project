import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { SmallbroComponent } from './smallbro/smallbro.component';
import { BigbroComponent } from './bigbro/bigbro.component';

@NgModule({
  declarations: [
    AppComponent,
    SmallbroComponent,
    BigbroComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
